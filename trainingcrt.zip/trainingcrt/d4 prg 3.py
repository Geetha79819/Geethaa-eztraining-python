#character present or not
s=input('string:')
ch=input('chrt:')
if ch in s:
    print("present")
else:
    print("not present")
