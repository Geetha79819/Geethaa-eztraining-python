i=1
while i<=15:
    print(i)
    i=i+1
