crt python day 3 content
l=[1,4,7.4,"sam"]
l
[1,4,7.4,"sam"]
l[3]
'sam'
l[2:3]
[7.4]
l[2:4]
[7.4,'sam']
l[0:]
[1,4,7.4,'sam']
l[:3]
[1,4,7.4]
l[-1]
'sam'
l[::-1]
['sam',7.4,4,1]
