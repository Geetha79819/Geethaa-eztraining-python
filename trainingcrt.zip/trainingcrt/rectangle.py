l=10
b=5
a=l*b
print(a)
