print("its",'a','good','day','')

print("all",'is','good',sep="***",'')


