thislist=["a","b","c","d"]
print (thislist[2:])
