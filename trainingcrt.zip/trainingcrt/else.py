t=5
if t>26:

    print("yes")
elif t==26:
        print("its eaual")
elif t<26:
            print("its less")
