crt day 4 content -2
mutable:
set
list
dictionary
inmutable:
int
float
string

#after getting a string as input check your string contain spaces or not if yes then count no of spaces in it and find it
#get one string as input along with one character find out and display whether that particular character is present or not
#check whether string is palindrome or not
#create a list with vowels get one string as input count vowel from the string and display result#MATH MODULE
import math
print( "CeIL 12.5:",math.ceil(12.500
print( "FLOOR 12.5:",math.floor(12.5))
print( "SQRT 345:",math.sqrt(345))
print( "FACTORIAL 3:",math.factorial(3))
print( "power 2,3:",math.pow(2,3))
print( "Remainder 10,3:",math.
    