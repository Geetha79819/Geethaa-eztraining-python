l=10
b=5
a=2*(l+b)
 print(a)
