s=input("enter a string: ")
count=0
for i in s:
    if(" " in s):
        count = count+1
        print(count)
