#MATH MODULE
import math
print( "CeIL 12.5:",math.ceil(12.500
print( "FLOOR 12.5:",math.floor(12.5))
print( "SQRT 345:",math.sqrt(345))
print( "FACTORIAL 3:",math.factorial(3))
print( "power 2,3:",math.pow(2,3))
print( "Remainder 10,3:",math.fmod(
    
