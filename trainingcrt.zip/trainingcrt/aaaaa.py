n=int(input("enter a number to check it is divisible 2 and 5 : "))
if n%2==0 & n%5==0:
    print("it is divisible by both 2 and 5")
else:
    print("not divisible")
            
