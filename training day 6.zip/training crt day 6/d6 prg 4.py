x=6
if x%2!=0:
    raise Exception("x should be even number")
else:
    print("x is even number...correct")
