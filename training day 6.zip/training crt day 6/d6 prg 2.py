a=10
b=0
try:
    print("resource open")
    print(a/b)
except Exception as e:
    print("dont give second no.as zero",e)
finally:
     print("resources closed")
