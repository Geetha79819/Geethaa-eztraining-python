class computer:
    def config(self):
        print("yes")
lenova=computer()
lenova.config()
dell=computer()
dell.config()
