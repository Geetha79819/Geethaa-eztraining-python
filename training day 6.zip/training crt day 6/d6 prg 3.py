a=10
try:
    b=int(input("enter the number"))
    print("resource open")
    print(a/b)
except zeroDivisionError as e:
    print("please note,number cant be divided by zero")
except valueerror as e:
    print("invalid input")
except Exception as e:
    print("other error",e)
finally:
     print("resource closed")
    
